const firebaseConfig = {
    apiKey: "AIzaSyASrVM8ymvqNYUNXGgfEvYlTKSiW7IbLRI",
    authDomain: "onlinelibrary-52150.firebaseapp.com",
    databaseURL: "https://onlinelibrary-52150-default-rtdb.firebaseio.com",
    projectId: "onlinelibrary-52150",
    storageBucket: "onlinelibrary-52150.appspot.com",
    messagingSenderId: "765466863204",
    appId: "1:765466863204:web:72cef50bc491671ca46171"
  };

  //initialising a database
  firebase.initializeApp(firebaseConfig);

  //reference a database
  
  var onlineLibraryDB = firebase.database().ref('onlineLibrary');

  document.getElementById('singUpform').addEventListener('submit' , submitDetails);

  function submitDetails(e){
    e.preventDefault();
     
    var name = getElementVal('name');
    var email = getElementVal('email');
    var password1 = getElementVal('password1');
    var password2 = getElementVal('password2');

    if(password1 == password2){
    saveData(name , email , password1 , password2);
    }
  }

  const saveData = (userName , userEmail , userPassword1 , userPassword2) =>{
   var newSignup = onlineLibraryDB.push();

   newSignup.set({
    userName: userName,
    userEmail: userEmail,
    userPassword1: userPassword1,
    userPassword2: userPassword2,
   });
  };

  const getElementVal = (id) => {
    return document.getElementById(id).value;
  }; 