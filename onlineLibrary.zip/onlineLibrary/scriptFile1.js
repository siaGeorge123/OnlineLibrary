    
  
         /*---- login form -------*/

         var loginForm = document.querySelector('.login-form-container');

         document.querySelector('#login-btn').onclick = () => {
             loginForm.classList.toggle('active');
         }
         
         document.querySelector('#shop_button').onclick = () => {
             loginForm.classList.toggle('active');
         }
         
         document.querySelector('#shop_button2').onclick = () => {
             loginForm.classList.toggle('active');
         }
         
         document.querySelector('#close-login-btn').onclick = () =>{
             loginForm.classList.remove('active');
         }
         
         
         
         /*---- swiper  -------*/
         
         var swiper = new Swiper(".books-list", {
         
           loop:true,
           centeredSlides:true,
           autoplay:{
             delay:9500,
             disableOnInteraction:false,
           },
           breakpoints: {
             0: {
               slidesPerView:1,
             },
             768: {
               slidesPerView:2,
             },
             1024: {
               slidesPerView:3,
             },
           },
         });
         
         
         
         
             const creationButton = document.getElementById('create');
             
             const signinContainer = document.querySelector('.signin');
             const signupContainer = document.querySelector('.signup');
         
             creationButton.addEventListener('click', () => {
                 
                 signinContainer.classList.add('hidden');
                 signupContainer.classList.remove('hidden');
                 
             });
             
             //-------------------------------------
             
             const resetButton = document.getElementById('resert');
             
             const signContainer = document.querySelector('.signin');
             const resetContainer = document.querySelector('.resert-password');
         
             resetButton.addEventListener('click', () => {
                 
                 signContainer.classList.add('hidden');
                 resetContainer.classList.remove('hidden');
                 
             });
           
           
           //-------------------------------------
             
             const getOtpButton = document.getElementById('get-otp');
             
             const otpContainer = document.querySelector('.otp-container');
             const resetingContainer = document.querySelector('.resert-password');
         
             getOtpButton.addEventListener('click', () => {
                 
                 resetingContainer.classList.add('hidden');
                 otpContainer.classList.remove('hidden');
                 
             });
           
           
           
            const passwordFields = document.querySelectorAll('.form-group input[type="text"]');
             passwordFields.forEach((field, index) => {
                 field.addEventListener('input', (event) => {
                     const value = event.target.value;
                     if (value.length === 1) {
                         if (index < passwordFields.length - 1) {
                             passwordFields[index + 1].focus();
                         }
                     } else if (value.length === 0) {
                         if (index > 0) {
                             passwordFields[index - 1].focus();
                         }
                     }
                 });
             });

       // ----------------------------- pop out box -------------------------------
       document.getElementById('submitButton').addEventListener('click', function() {

        const nameBox = document.getElementById('name').value.trim();
        const emailBox = document.getElementById('email').value.trim();
        const password1Box = document.getElementById('password1').value.trim();
        const password2Box = document.getElementById('password2').value.trim();

        if (nameBox !== '' && emailBox !== '' && password1Box !== '' && password2Box !== '' && password1Box == password2Box) {
            document.getElementById('messageContent1').innerText = "Account Created !!!";
            document.getElementById('messageBox1').style.display = 'flex';
        } else {
            document.getElementById('messageContent2').innerText = "Complete form make sure \n passwords also match !!!";
            document.getElementById('messageBox2').style.display = 'flex';
        }

    });

    document.getElementById('closeButton1').addEventListener('click', function() {
        document.getElementById('messageBox1').style.display = 'none';
    });

    document.getElementById('closeButton2').addEventListener('click', function() {
        document.getElementById('messageBox2').style.display = 'none';
    });