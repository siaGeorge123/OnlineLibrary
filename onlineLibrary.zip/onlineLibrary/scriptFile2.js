var swiper = new Swiper(".featured-slider", {

    spaceBetween:10,
    loop:true,
    centeredSlides:true,
    autoplay:{
      delay:9500,
      disableOnInteraction:false,
    },
   navigation:{
          nextEl:".swiper-button-next",
          prevEl:".swiper-button-prev",
      },
    breakpoints: {
      0: {
        slidesPerView:1,
      },
      450: {
        slidesPerView:2,
      },
      768: {
        slidesPerView:3,
      },
      1024: {
        slidesPerView:4,
      },
    },
  });
  
  
  
  
   /*------ review section --------*/
  
    var swiper = new Swiper(".reviews-slider", {
      spaceBetween:10,
      loop:true,
      centeredSlides:true,
      autoplay:{
        delay:9500,
        disableOnInteraction:false,
      },
      breakpoints: {
        0: {
          slidesPerView:1,
        },
        768: {
          slidesPerView:2,
        },
        1024: {
          slidesPerView:3,
        },
      },
    });
  
  
        
    /*-------- arrivals section start ---------- */
  
    var swiper = new Swiper('.arrivals-slider', {
      spaceBetween:10,
      loop:true,
      centeredSlides:true,
      autoplay:{
        delay:9500,
        disableOnInteraction:false,
      },
      breakpoints: {
        0: {
          slidesPerView:1,
        },
        768: {
          slidesPerView:2,
        },
        1024: {
          slidesPerView:3,
        },
      },
    });
    
    /*---- cart form -------*/
  
  var cartForm = document.querySelector('.cart-form-container');
  
  document.querySelector('#cart-btn').onclick = () => {
      cartForm.classList.toggle('active');
  }
  
  document.querySelector('#close-cart-btn').onclick = () =>{
      cartForm.classList.remove('active');
  }
  
  //---------------------------------------Available books--------------------
  
       // Array of strings
      const booksArray = ["The art city", "Thanks in everything", "Marine life", "The helper's hand", "Step guiter",
      "Simple living","The peaceful tower","Child groom","the red love","GMO"];
  
      // Function to check if the entered string is in the array
      function checkString() {
        const inputText = document.getElementById("search-box").value.toLowerCase(); // Convert input to lowercase
  
        // Check if the input string (in lowercase) is in the array (also converted to lowercase)
        if (booksArray.map(str => str.toLowerCase()).includes(inputText)) {
          alert(`The Book    :    ${inputText}    :    is currently available "\n"Please scroll to locate it.`);
        } else {
          alert(`The searched Book     :   ${inputText}     :   is currentlry unavailable"\n"Please check again after few days.`);
        }
      }
    
    
       // JavaScript code to handle adding items to cart
       
      const cart = {}; // Empty object to store cart items
      let totalPrice = 0;
  
      function addItem(itemName, itemPrice, itemImage) {
          if (cart[itemName]) {
              cart[itemName].quantity++;
          } else {
              cart[itemName] = { quantity: 1, price: itemPrice, image: itemImage };
          }
          totalPrice += itemPrice;
          updateCartDisplay();
      }
  
      function removeItem(itemName, itemPrice) {
          if (cart[itemName]) {
              if (cart[itemName].quantity > 1) {
                  cart[itemName].quantity--;
              } else {
                  delete cart[itemName];
              }
              totalPrice -= itemPrice;
              updateCartDisplay();
          }
      }
  
      function updateCartDisplay() {
          const cartItems = document.getElementById('cart-items');
          cartItems.innerHTML = ''; // Clear the existing table
          totalPrice = 0;
  
          // Loop through the cart object and display each item in a table row
          for (const [itemName, itemInfo] of Object.entries(cart)) {
              const row = document.createElement('tr');
              const itemCell = document.createElement('td');
              const img = document.createElement('img');
              img.src = itemInfo.image;
              img.alt = itemName;
              img.width = 50;
              img.height = 50;
              itemCell.appendChild(img);
              itemCell.innerHTML += ` ${itemName}`;
              const quantityCell = document.createElement('td');
              quantityCell.textContent = itemInfo.quantity;
              const priceCell = document.createElement('td');
              priceCell.textContent = `R${itemInfo.price * itemInfo.quantity}`;
              const actionCell = document.createElement('td');
              const removeButton = document.createElement('button');
              removeButton.textContent = 'Remove';
              removeButton.className = 'remove-button';
              removeButton.onclick = function() {
                  removeItem(itemName, itemInfo.price);
              };
              actionCell.appendChild(removeButton);
              row.appendChild(itemCell);
              row.appendChild(quantityCell);
              row.appendChild(priceCell);
              row.appendChild(actionCell);
              cartItems.appendChild(row);
  
              // Calculate total price
              totalPrice += itemInfo.price * itemInfo.quantity;
          }
  
          // Update total price
          document.getElementById('total-price').textContent = `R${totalPrice.toFixed(2)}`;
      }

     
      
      
    